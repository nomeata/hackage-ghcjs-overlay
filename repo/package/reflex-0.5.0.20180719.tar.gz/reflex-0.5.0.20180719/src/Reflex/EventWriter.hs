module Reflex.EventWriter
  {-# DEPRECATED "Use 'Reflex.EventWriter.Class' and 'Reflex.EventWriter.Base' instead, or just import 'Reflex'" #-}
  ( module X
  ) where

import Reflex.EventWriter.Base as X
import Reflex.EventWriter.Class as X
