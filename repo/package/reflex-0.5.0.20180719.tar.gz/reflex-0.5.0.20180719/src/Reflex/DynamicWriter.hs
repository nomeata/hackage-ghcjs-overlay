module Reflex.DynamicWriter
  {-# DEPRECATED "Use 'Reflex.DynamicWriter.Class' and 'Reflex.DynamicWrite.Base' instead, or just import 'Reflex'" #-}
  ( module X
  ) where

import Reflex.DynamicWriter.Base as X
import Reflex.DynamicWriter.Class as X
