module JavaScript.Web.History () where

-- todo: implement
