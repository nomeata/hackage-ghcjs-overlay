module JavaScript.Web.Blob ( Blob
                           , size
                           , contentType
                           , slice
                           , isClosed
                           , close
                           ) where

import JavaScript.Web.Blob.Internal

