module JavaScript.JSON where

import JavaScript.JSON.Types
import JavaScript.JSON.Types.Internal

{-
class FromJSON a where
  parseJSON :: Value -> Parser a

class ToJSON a where
  toJSON :: a -> Value
-}
