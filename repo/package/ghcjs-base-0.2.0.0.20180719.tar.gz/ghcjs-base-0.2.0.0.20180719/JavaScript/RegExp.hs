module JavaScript.RegExp
    ( module Data.JSString.RegExp
    ) where

import Data.JSString.RegExp
