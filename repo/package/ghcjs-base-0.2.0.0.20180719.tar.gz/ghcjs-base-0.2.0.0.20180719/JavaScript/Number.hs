module JavaScript.Number where

